package net.tinyos.prowler.extension;

public interface Displayable {
	public void displayOn(ISimulationDisplay disp);
}
