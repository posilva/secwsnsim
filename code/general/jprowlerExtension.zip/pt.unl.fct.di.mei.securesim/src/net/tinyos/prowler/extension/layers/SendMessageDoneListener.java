/**
 * 
 */
package net.tinyos.prowler.extension.layers;

import java.util.EventListener;

/**
 * @author posilva
 *
 */
public interface SendMessageDoneListener extends EventListener {
	public void onMessageDone(MessageEvent evt);
}
