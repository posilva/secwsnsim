/**
 * 
 */
package net.tinyos.prowler.extension.energy;

import java.util.EventListener;

/**
 * @author posilva
 *
 */
public interface EnergyListener extends EventListener {
	
}
