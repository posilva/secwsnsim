package net.tinyos.prowler.extension.test;

public interface IApplicationFactory <T>{
	public  T createInstance();
}
