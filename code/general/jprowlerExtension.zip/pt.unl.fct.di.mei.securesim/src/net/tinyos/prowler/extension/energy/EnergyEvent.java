/**
 * 
 */
package net.tinyos.prowler.extension.energy;

import java.util.EventObject;

/**
 * @author posilva
 *
 */
public class EnergyEvent extends EventObject {

	public EnergyEvent(Object arg0) {
		super(arg0);
	}

}
