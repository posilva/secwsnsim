/**
 * 
 */
package net.tinyos.prowler.extension.messages;

import java.io.Serializable;

/**
 * @author posilva
 *
 */
public abstract class Message<T> implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4744406504553740956L;
	private T data;

	/**
	 * @param data the data to set
	 */
	public void setData(T data) {
		this.data = data;
	}

	/**
	 * @return the data
	 */
	public T getData() {
		return data;
	}

}
