/*
 * Copyright (c) 2003, Vanderbilt University
 * All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice, the following
 * two paragraphs and the author appear in all copies of this software.
 * 
 * IN NO EVENT SHALL THE VANDERBILT UNIVERSITY BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE VANDERBILT
 * UNIVERSITY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE VANDERBILT UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE VANDERBILT UNIVERSITY HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 *
 * Author: Gyorgy Balogh, Gabor Pap, Miklos Maroti
 * Date last modified: 02/09/04
 */
 
package net.tinyos.prowler.original;

import net.tinyos.prowler.original.RadioModel.Neighborhood;

/**
 * This class is the base class of all nodes. Nodes are entities in a simulator
 * which act on behalf of themselves, they also have some basic attributes like 
 * location. Nodes also take part in radio transmissions, they initiate 
 * transmissions and receive incomming radio messages.
 * 
 * @author Gabor Pap, Gyorgy Balogh, Miklos Maroti
 */
public abstract class Node {
	/**
	 * Nodes of the Simulator are linked together in a single linked list. 
	 * This points to the next element.
	 */
	public Node nextNode = null;
	
	/**
	 * The applications of the TinyOs node are linked together
	 * in a single linked list. This points to the first,
	 * and then {@link Application#nextApplication} to the next. 
	 */
	protected Application firstApplication = null;

	/** 
	 * This field defines the relative strength of a mote. If it is set to
	 * a high value for a given mote it can supress other motes.
	 */
	double maxRadioStrength = 100;	

	/** positions x in meters (not that it metters much) */
	protected double    x = 0;

	/** positions y in meters (not that it metters much) */
	protected double    y = 0;
	
	/** positions z in meters (not that it metters much) */
	protected double    z = 0;
    
	/** A reference to the simulator in which the Node exists. */
	public Simulator simulator;

	/**
	 * The id of the node. It is allowed that two nodes have
	 * the same id in the simulator.
	 */
	protected short id;
	
	/**
	 * The neighborhood of this node, meaning all the neighboring nodes which 
	 * interact with this one.
	 */
	public Neighborhood neighborhood;

	/**
	 * Parameterized constructor, sets the simulator and creates an initial 
	 * neighborhood using the RadioModel as a factory.
	 * 
	 * @param sim the Simulator
	 * @param radioModel the RadioModel used to create the nodes neighborhood
	 */
	public Node(Simulator sim, RadioModel radioModel){
		this.simulator = sim;
		neighborhood = radioModel.createNeighborhood();
	} 
	
	/* (non-Javadoc)
	 * @see net.tinyos.prowler.INode#getNeighborhood()
	 */
	public Neighborhood getNeighborhood(){
		return neighborhood;
	}

	/* (non-Javadoc)
	 * @see net.tinyos.prowler.INode#getDistanceSquare(net.tinyos.prowler.Node)
	 */		
	public double getDistanceSquare(Node other){
		return (x-other.x)*(x-other.x) + (y-other.y)*(y-other.y) + (z-other.z)*(z-other.z);
	} 

	/* (non-Javadoc)
	 * @see net.tinyos.prowler.INode#getMaximumRadioStrength()
	 */
	public double getMaximumRadioStrength(){
		return maxRadioStrength;
	}
	
	/* (non-Javadoc)
	 * @see net.tinyos.prowler.INode#setMaximumRadioStrength(double)
	 */
	public void setMaximumRadioStrength(double d) {
		maxRadioStrength = d;
	}
	
	/**
	 * Called by the drived class implementing the MAC layer when
	 * radio transmission is initiated. This method will call the
	 * {@link Node#receptionBegin} method in each of the neighboring
	 * nodes with the same <code>stream</code> object but with
	 * a diminished radio signal strength. Derived classes must
	 * avoid nested transmissions. 
	 * 
	 * @param strength The signal strength of the transmission. This
	 * must be positive and less than or equal to the maximum transmit
	 * strength.
	 * @param stream The object that is beeing sent. This parameter
	 * cannot be <code>null</code> and two nodes cannot send
	 * the same object at the same time.
	 * @see Node#getTransmitStrengthMultiplicator
	 */		
	protected final void beginTransmission(double strength, Object stream) {
		neighborhood.beginTransmission(strength, stream);
	}

	/**
	 * Called by the derived class implementing the MAC layer when
	 * radio transmission is finished. This method will call the
	 * {@link Node#receptionEnd} method in each  of the neighboring
	 * nodes with the same <code>stream</code> object but
	 * with a diminished radio strength. Derived classes must make
	 * sure that this method is invoked only once for each matching
	 * {@link Node#beginTransmission} call.
	 */
	protected final void endTransmission() {
		neighborhood.endTransmission();
	}

	/**
	 * Called for each transmission of a neighboring node by the 
	 * radio model. The <code>recpetionBegin</code> and 
	 * <code>receptionEnd</code> calles can be nested or interleaved, 
	 * but they are always coming in pairs. The derived class 
	 * implementing the MAC protocol must select the transmission 
	 * that it wants to receive based on some heuristics on the 
	 * radio signal stregths. Note that these methods are called 
	 * even when the nodes is currently transmitting. 
	 * 
	 * @param strength The radio strength of the incoming signal.
	 * @param stream The object representing the incoming data.
	 * This stream object is never <code>null</code>.
	 * @see #receptionEnd
	 */
	protected abstract void receptionBegin(double strength, Object stream);

	/**
	 * Called for each transmission of a neighboring node by the 
	 * radio model. This method is always invoked after a corresponding
	 * {@link #receptionBegin} method invokation with the exact same 
	 * parameters.
	 * 
	 * @param strength The radio strength of the incoming signal.
	 * @param stream The received object message.
	 */
	protected abstract void receptionEnd(double strength, Object stream);
	
	/* (non-Javadoc)
	 * @see net.tinyos.prowler.INode#sendMessage(java.lang.Object, net.tinyos.prowler.Application)
	 */
	public abstract boolean sendMessage(Object message, Application app);
	
	/* (non-Javadoc)
	 * @see net.tinyos.prowler.INode#setId(short)
	 */
	public void setId( short id ){
		this.id = id;
	}

	/* (non-Javadoc)
	 * @see net.tinyos.prowler.INode#setPosition(double, double, double)
	 */
	public void setPosition( double x, double y, double z ){
		this.x = x;
		this.y = y;
		this.z = z;
	}

	/* (non-Javadoc)
	 * @see net.tinyos.prowler.INode#getX()
	 */
	public double getX(){
		return x;
	}

	/* (non-Javadoc)
	 * @see net.tinyos.prowler.INode#getY()
	 */
	public double getY(){
		return y;
	}

	/* (non-Javadoc)
	 * @see net.tinyos.prowler.INode#getZ()
	 */
	public double getZ(){
		return z;
	}
	
	/* (non-Javadoc)
	 * @see net.tinyos.prowler.INode#getId()
	 */
	public short getId(){
		return id;
	}
	
	/* (non-Javadoc)
	 * @see net.tinyos.prowler.INode#getSimulator()
	 */
	public Simulator getSimulator(){
		return simulator;
	}
	
	/* (non-Javadoc)
	 * @see net.tinyos.prowler.INode#addApplication(net.tinyos.prowler.Application)
	 */
	public void addApplication(Application app){
		app.nextApplication = firstApplication;
		firstApplication = app;
	}

	/**
	 * Visiting the elements of the application list, it returns the first with
	 * the given application class.
	 * 
	 * @param appClass the class that identifies the needed application for us
	 * @return Returns the application instance running on this node
	 */
	@SuppressWarnings("unchecked")
	protected Application getApplication(Class appClass){
		Application tempApp = firstApplication;
		while (tempApp != null && tempApp.getClass() != appClass )
			tempApp = tempApp.nextApplication;
		return tempApp;
	}
	
	/* (non-Javadoc)
	 * @see net.tinyos.prowler.INode#display(net.tinyos.prowler.Display)
	 */
	public void display(Display disp){
		Application tempApp = firstApplication;
		while(tempApp != null){
			tempApp.display(disp);
			tempApp = tempApp.nextApplication;
		} 
	}
	
	/* (non-Javadoc)
	 * @see net.tinyos.prowler.INode#init()
	 */
	public abstract void init();
}
