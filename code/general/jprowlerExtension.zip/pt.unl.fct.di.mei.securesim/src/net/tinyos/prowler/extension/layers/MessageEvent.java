/**
 * 
 */
package net.tinyos.prowler.extension.layers;

import java.util.EventObject;


/**
 * @author posilva
 *
 */
@SuppressWarnings("serial")
public class MessageEvent extends EventObject {

	public MessageEvent(Object source) {
		super(source);
	}

}
