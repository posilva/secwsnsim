/**
 * 
 */
package net.tinyos.prowler.extension.test;

import net.tinyos.prowler.extension.Application;
import net.tinyos.prowler.extension.Node;
import net.tinyos.prowler.extension.layers.RoutingLayer;

/**
 * @author posilva
 *
 */
public class BroadcastRoutingLayer extends RoutingLayer {

	private Node parent;
	public BroadcastRoutingLayer() {
		super();
	}

	/**
	 * Stores the sender from which it first receives the message, and passes 
	 * the message.
	 */
	@Override
	public void receiveMessage(Object message, Application sendApplication ){
			if (parent == null){
				parent = getNode().getParentNode();
				Application app = getNode().getApplication(sendApplication.getClass());
				if(app!=null)	app.receiveMessage(message);
			}            
	}    
	@Override
	public boolean sendMessage(Object message, Application app){
		if (senderApplication!=null) return false;
		this.senderApplication = app;
		return getNode().sendMessage(message, this);
	}
	
	/**
	 * Sets the sent flag to true. 
	 */
	@Override
	public void sendMessageDone(){
		senderApplication.sendMessageDone();
		senderApplication=null;
	}
	
}
