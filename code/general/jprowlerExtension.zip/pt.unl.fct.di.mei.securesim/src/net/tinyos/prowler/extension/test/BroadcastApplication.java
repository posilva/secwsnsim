package net.tinyos.prowler.extension.test;

import net.tinyos.prowler.extension.Application;

/**
 * This extension of the {@link Application} baseclass does everything we 
 * expect from the broadcast application, simply forwards the message once,
 * and that is it. 
 */
public class BroadcastApplication extends Application{

		/**
		 * @param node the Node on which this application runs.
		 */
		public BroadcastApplication() {
			super();
		}
    
		/**
		 * Stores the sender from which it first receives the message, and passes 
		 * the message.
		 */
		public void receiveMessage(Object message ){
			if (message instanceof String && getNode().getId()==Short.parseShort((String)message) ){
				System.out.println("CHEGOU A MENSAGEM");
			} else{
				if (getBroadcastNode().getParent() == null){
					getBroadcastNode().setParent(getNode().getParentNode());
					sendMessage( message );
				}            
			}
		}    

		/**
		 * Sets the sent flag to true. 
		 */
		public void sendMessageDone(){
			getBroadcastNode().sentMenssage(true);            
		}

		
		private BroadcastNode getBroadcastNode() {
			return (BroadcastNode) getNode();

		}

		public static BroadcastApplication createInstance() {
			return new BroadcastApplication();
		}

	
}
